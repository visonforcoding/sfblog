<?php

/**
* Encoding     :   UTF-8
* Created on   :   2014-12-7 19:50:20 by 曹文鹏 , caowenpeng1990@126.com
*/
define('DATA_PATH',  preg_replace('/config/', '', __DIR__).'data/');
return array(
    
);