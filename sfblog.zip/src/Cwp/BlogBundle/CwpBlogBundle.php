<?php

namespace Cwp\BlogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CwpBlogBundle extends Bundle
{
}
