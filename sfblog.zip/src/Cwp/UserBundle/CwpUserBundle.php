<?php

namespace Cwp\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CwpUserBundle extends Bundle
{
 

}
